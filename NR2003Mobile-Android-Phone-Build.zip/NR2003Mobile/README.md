# NR2003 Mobile — Android foundation (prototype)

This is an Android Studio starter project for a user-supplied NR2003 installation workflow.

## Current scope
- Kotlin + Jetpack Compose launcher/import UI.
- Android Storage Access Framework folder and ZIP selection.
- Basic installation scan and report (heuristic; not a complete NR2003 validator).
- Native C++ JNI boundary and an OpenGL ES 3.0 surface clear/render loop.
- NDK ABI targets: `arm64-v8a` and `armeabi-v7a`.

## Important status
This is **not a playable NR2003 port and does not contain an NR2003 engine**.
The supplied OpenNR2003 archive README says its non-source files are Ghidra project files and lists decompilation, cross-platform support, and modern OpenGL as project goals. It does not provide a ready-to-build engine or Android translation layer.

A real native Android port requires reconstructing/reimplementing the game code and replacing Windows-specific APIs. A CPU translation layer cannot be conjured by the installer: if original game code is x86/x64, ARM devices need either a compatible ARM build or a separately engineered instruction/runtime translation solution. This project deliberately does not pretend that is already solved.

## Build
1. Install Android Studio with Android SDK, NDK, and CMake.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Build `app` for a connected ARM64 or ARMv7 Android device.

The project uses Android Gradle Plugin 8.7.3, Gradle 8.9, Kotlin 2.0.21, and Compose.


## Build an APK using only an Android phone (GitHub Actions)
1. Create/sign in to a GitHub account in your phone browser.
2. Create a **public or private** repository named `NR2003Mobile`.
3. Upload the contents of this project ZIP to the repository (extract the ZIP first; upload the files and folders inside it, including `.github`).
4. Open the repository's **Actions** tab. If prompted, enable Actions.
5. Select **Build Android APK** and tap **Run workflow** (or push to `main`).
6. When the workflow finishes successfully, open its run, scroll to **Artifacts**, and download `NR2003-Mobile-debug-APK`.
7. Extract the artifact ZIP on Android and install `app-debug.apk`. You may need to allow installs from your browser/files app.

This cloud workflow builds the installer/rendering prototype only. It does not make NR2003 playable; the actual game engine, Windows API compatibility, CPU translation, and game rendering still need substantial implementation. The APK is a debug build, not a Play Store release.
