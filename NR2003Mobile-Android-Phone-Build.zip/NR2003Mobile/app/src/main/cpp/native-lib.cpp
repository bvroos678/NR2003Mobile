#include <jni.h>
#include <GLES3/gl3.h>
#include <android/log.h>

#define LOG_TAG "NR2003Mobile"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT jstring JNICALL
Java_com_nr2003mobile_NativeBridge_rendererInfo(JNIEnv* env, jobject) {
    const char* version = reinterpret_cast<const char*>(glGetString(GL_VERSION));
    if (!version) version = "OpenGL ES context not current; renderer scaffold initialized by Android";
    return env->NewStringUTF(version);
}

// Rendering integration point. A real port must connect reconstructed game rendering
// and simulation code here; clearing a frame is only a graphics smoke-test.
extern "C" JNIEXPORT void JNICALL
Java_com_nr2003mobile_NativeBridge_clearFrame(JNIEnv*, jobject) {
    glClearColor(0.035f, 0.055f, 0.075f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}
