package com.nr2003mobile

object NativeBridge {
    init { System.loadLibrary("nr2003mobile") }
    external fun rendererInfo(): String
    external fun clearFrame()
}
