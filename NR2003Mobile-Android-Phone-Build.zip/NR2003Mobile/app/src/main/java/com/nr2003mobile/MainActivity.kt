package com.nr2003mobile

import android.content.Intent
import android.net.Uri\nimport android.opengl.GLSurfaceView\nimport android.view.ViewGroup
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material3.*
import androidx.compose.runtime.*\nimport androidx.lifecycle.lifecycleScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier\nimport androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.zip.ZipInputStream

private val RacingRed = Color(0xFFD92332)
private val Ink = Color(0xFF101820)

class MainActivity : ComponentActivity() {
    private val pickerFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION); selectedFolder = it; scanFolder(it) }
    }
    private val pickerZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION); scanZip(it) }
    }
    private var selectedFolder by mutableStateOf<Uri?>(null)
    private var status by mutableStateOf("No game files selected")
    private var details by mutableStateOf("Import a folder or ZIP containing your own NR2003 installation.")
    private var busy by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = RacingRed, background = Ink, surface = Color(0xFF1B2833))) {
                val scope = rememberCoroutineScope()
                Surface(Modifier.fillMaxSize(), color = Ink) {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Flag, null, tint = RacingRed, modifier = Modifier.size(34.dp))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("NR2003 MOBILE", style = MaterialTheme.typography.titleLarge)
                                Text("ANDROID INSTALLER · PROTOTYPE", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Column(Modifier.fillMaxWidth().background(Color(0xFF1B2833), RoundedCornerShape(18.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Bring the track to mobile", style = MaterialTheme.typography.headlineMedium)
                            Text("Import your own game files. The app scans the selected source and reports what it finds.")\n                            Text("OPENGL ES 3.0 RENDERER TEST", color = RacingRed, style = MaterialTheme.typography.labelMedium)\n                            AndroidView(modifier = Modifier.fillMaxWidth().height(150.dp), factory = { ctx ->\n                                GLSurfaceView(ctx).apply {\n                                    setEGLContextClientVersion(3)\n                                    setRenderer(object : GLSurfaceView.Renderer {\n                                        override fun onSurfaceCreated(gl: javax.microedition.khronos.opengles.GL10?, config: javax.microedition.khronos.egl.EGLConfig?) { }\n                                        override fun onSurfaceChanged(gl: javax.microedition.khronos.opengles.GL10?, width: Int, height: Int) { GLESViewport.resize(width, height) }\n                                        override fun onDrawFrame(gl: javax.microedition.khronos.opengles.GL10?) { NativeBridge.clearFrame() }\n                                    })\n                                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY\n                                }\n                            })
                            Button(onClick = { pickerFolder.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Choose game folder")
                            }
                            OutlinedButton(onClick = { pickerZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Archive, null); Spacer(Modifier.width(8.dp)); Text("Choose ZIP archive")
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2833))) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("INSTALLATION SCAN", color = RacingRed, style = MaterialTheme.typography.labelLarge)
                                Text(status, style = MaterialTheme.typography.titleMedium)
                                Text(details, color = Color.LightGray)
                                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2833))) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("DEVICE / ENGINE TARGETS", color = RacingRed, style = MaterialTheme.typography.labelLarge)
                                Text("ARM64 (primary) · ARMv7 (secondary)")
                                Text("OpenGL ES 3.0 renderer scaffold · Vulkan can be added as a separate backend")
                                Text("Windows API / x86-to-ARM translation: not implemented")
                            }
                        }
                        Text("This prototype is an installer and graphics foundation, not a playable game. It does not include NR2003 copyrighted game data.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    private fun scanFolder(uri: Uri) {
        status = "Scanning selected folder…"; details = "Reading file and directory names."; busy = true
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                val root = DocumentFile.fromTreeUri(this@MainActivity, uri)
                val names = mutableListOf<String>()
                fun walk(dir: DocumentFile, depth: Int) {
                    if (depth > 5 || names.size > 5000) return
                    dir.listFiles().forEach { f ->
                        names += (if (f.isDirectory) "DIR " else "FILE ") + (f.name ?: "unnamed")
                        if (f.isDirectory) walk(f, depth + 1)
                    }
                }
                if (root != null) walk(root, 0)
                summarize(names)
            }
            status = result.first; details = result.second; busy = false
        }
    }

    private fun scanZip(uri: Uri) {
        status = "Scanning ZIP archive…"; details = "Checking archive entries without extracting them."; busy = true
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                val names = mutableListOf<String>()
                contentResolver.openInputStream(uri)?.use { input ->
                    ZipInputStream(input).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null && names.size < 10000) {
                            names += (if (entry.isDirectory) "DIR " else "FILE ") + entry.name
                            entry = zip.nextEntry
                        }
                    }
                }
                summarize(names)
            }
            status = result.first; details = result.second; busy = false
        }
    }

    private fun summarize(names: List<String>): Pair<String, String> {
        val lower = names.map { it.lowercase() }
        val exe = lower.filter { it.endsWith(".exe") }
        val tracks = lower.count { it.contains("tracks") || it.contains("track") }
        val cars = lower.count { it.contains("cars") || it.contains("car") }
        val likely = exe.any { it.contains("nr2003") || it.contains("nascar") } ||
            lower.any { it.contains("tracks") && it.contains("series") }
        val summary = "Scanned ${names.size} entries · ${exe.size} executable(s) · $tracks track-related · $cars car-related"
        return if (likely) "Possible NR2003 installation detected" to "$summary.\nThis is a heuristic match. Full validation and extraction are not implemented yet."
        else "Files scanned — NR2003 not confirmed" to "$summary.\nNo definitive NR2003 signature was found. Try selecting the game's root folder or full archive."
    }
}
\nprivate object GLESViewport { fun resize(width: Int, height: Int) { android.opengl.GLES20.glViewport(0, 0, width, height) } }\n